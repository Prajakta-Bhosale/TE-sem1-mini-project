from django.apps import AppConfig


class EventConfig(AppConfig):
    name = 'Event'

